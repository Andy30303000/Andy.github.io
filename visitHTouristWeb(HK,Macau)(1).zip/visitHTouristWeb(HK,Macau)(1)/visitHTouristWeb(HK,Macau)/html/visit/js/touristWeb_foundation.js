/*

Using this foundation file , you can just type in all the information of the attraction in the following order (1.name 2. SAR 3.district 4.type 5.price) and these code below will combine it all together .
After it helps you combine it all together , it helps you create the id of the paragraph of those information in format[ name(in lowercase and no space)_P(uppercase)   e.g.kowloonpark_P].
So, you can put photo link and information all together by a div tag .
To bulid a tourist attraction : 1. use .addAttraction() 2.

*/
var obj = {
    name: '',
    SAR: '',
    district: '',
    type: "",
    price:"",
    intro:""
    };
var container = document.createElement("div");
container.style.display = "flex";
container.style.flexDirection = "column";
container.style.alignItems = "center";
container.style.textAlign = "center";

var image = document.createElement("img");
image.src = obj.img;
image.style.width = "50%";
image.style.height = "50%";

var text = document.createElement("p");
text.id = obj.SearchTag + "_P";
text.innerHTML = "Name of the Attraction: " + obj.name + "<br>SAR: " + obj.SAR + "<br>District: " + obj.district + "<br>Type of attraction: " + obj.type + "<br>Price: $" + obj.price + "<br>Intro:<br>" + obj.intro;

var link = document.createElement("a");
link.href = obj.Link;
link.innerHTML = "Click here for more";

container.appendChild(image);
container.appendChild(text);
container.appendChild(link);

document.getElementById(ID).innerHTML = "";
document.getElementById(ID).appendChild(container);
//Object of Attraction
 function Attraction( site_name ,AdministrationRegion ,District, Type, Price){
    //Photo of the attraction
    this.img=null

    //name of this attraction
    this.name=site_name        
    
    //the name for user to search  *I wil change the input to a lowercase and see if the name same as this tag. If yes, it show up then
    this.SearchTag=this.name.toLowerCase().split(" ").join("")  
    
    //SAR of the attraction
    this.SAR=AdministrationRegion           
    
    //which type of attraction is it belongs to 
    this.type=Type                             
    
    // enter which district is the attraction belongs to 
    this.district=District                   
    
    //the short discription of the tiurist attraction
    this.intro="Sorry this attrction does not have any information "
    
    //how much travelling this site costs *as some tourist attraction need to pay for visit and some don't , you need to add it in the AA function below
    this.price=parseFloat(Price)                


    //the link of the attraction
    this.Link=null
}  



//====================================================================//

// this is a library for saving those  tourist attraction 
function Library(){
    this.AttractionLibrary={}
    this.addAttraction=AA
    this.displayAtt=DA
    this.addPhoto=Photo
    this.addIntro=setIntro
    this.addLink=setLink
    
}

// a function for you to add an tourist attraction to the library
function AA(site_name, AdministrationRegion, type, district,Price){
    if(site_name in this.AttractionLibrary){
        alert("This site is inside our library already")
    }

//for user and you to search more easily which you don't need to the upper and lowercase of the name of the tourist attraction, 
    else{
        // I change it so no matter where you input the space and lower or upper case it can search the attraction as well 
        SearchName=site_name.toLowerCase().split(" ").join("")
        this.AttractionLibrary[SearchName]= new Attraction(site_name, AdministrationRegion, type, district,Price)
    }
}


// a function for you to display all the information of a tourist attraction within the library
//*note that the paragraph should place before the script or it can't scan the id of the paragraph*/
function DA(Search,ID){
    SearchName=Search.toLowerCase().split(" ").join("")
    if (SearchName in this.AttractionLibrary){
        var obj= this.AttractionLibrary[SearchName]
        //here I help you set the id of the all the information 
        //**** PLEASE WRITE DOWN THE WIDTH AND HEIGHT OF ALL THE PHOTO BY YOUSELVE*****/
        document.getElementById(ID).innerHTML = '<img src="' + obj.img + '" style="width: 50%; height: 50%;"><br><p id="' + obj.SearchTag + '_P">Name of the Attraction: ' + obj.name + '<br>SAR: ' + obj.SAR + '<br>District: ' + obj.district + '<br>Type of attraction: ' + obj.type + '<br>Price: $' + obj.price + '<br>Intro:<br>' + obj.intro + '</p><a href="' + obj.Link + '">Click here for more</a>';    }
    // else{
    //     alert("This attraction does not inside our library")
    // }
}

//add photo of the tourist attraction
function Photo(Search,source){
    SearchName=Search.toLowerCase().split(" ").join("")
    if (SearchName in this.AttractionLibrary){
        var obj=this.AttractionLibrary[SearchName]
        obj.img=source
        
    }
    else{
        alert("There's no such Attraction")
    }
}

// write the info of this attraction
function setIntro(Search,inputParagraph){
    var SearchName=Search.toLowerCase().split(" ").join("")
    if(SearchName in this.AttractionLibrary){
        var obj=this.AttractionLibrary[SearchName]
        obj.intro=inputParagraph
    }
    //     else{
    //         alert("this site wasn't inside the library already")
    //     }
}

function setLink(Search,link){
    var SearchName=Search.toLowerCase().split(" ").join("")
    if(SearchName in this.AttractionLibrary){
        var obj=this.AttractionLibrary[SearchName]
        obj.Link=link
    }
//     else{
//         alert("this site wasn't inside the library already")
//     }
}

//These function will be used in the Hong Kong and Macau button in the main html file
//The lib parameter is for you to enter the library of those attractions

var Des=""
function Hong_Kong(lib){
    var i=0
    for(key in lib.AttractionLibrary){
        if(lib.AttractionLibrary[key].SAR=="Hong Kong"){
            lib.displayAtt(key,i.toString())
        }
        i+=1
        
    }
    return Des="Hong Kong"
    
}


function Macau(lib){
    var i=0
    for(key in lib.AttractionLibrary){
        if(lib.AttractionLibrary[key].SAR=="Macau"){
            lib.displayAtt(key,i.toString())
        }
        i+=1
        
    }
    return Des="Macau"
    
}


// when you use this functOion please help the user to input the lib first which i think you can put the value of the text into search and you type the lib
 function SearchFunc(Search,lib){
    var SearchName=Search.toLowerCase().split(" ").join("")
    if(SearchName in lib.AttractionLibrary){
        lib.displayAtt(SearchName,"0")
        //the for loop down below is used to remove elements inside other divs
        for(i=1;Object.keys(lib.AttractionLibrary).length;i++){ //Object.keys() is used to transfer the keys in the object into a list and then i use .length to get its length
            if(document.getElementById(i)!=""){
                document.getElementById(i).innerHTML="";
            }
            
        }
        
    }
    else{
        document.write("Sorry there's no such attraction or you may spell it wrong ")
    }
}

function showSelectedPreferences(lib) {
    const architecture = document.getElementById('architecture').checked;// return true or false
    const nature = document.getElementById('nature').checked;
    const art = document.getElementById('art').checked;
    const food = document.getElementById('food').checked;
    const shopping = document.getElementById('shopping').checked;
    
    var i=0
    if(architecture){
        if(Des!=""){
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='architecture'&& lib.AttractionLibrary[key].SAR==Des){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            }
        }
        else{
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='architecture'){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            } 
        }
    }
    
    if(nature){
        if(Des!=""){
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='nature'&& lib.AttractionLibrary[key].SAR==Des){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            }
        }
        else{
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='nature'){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            } 
        }
    }

    if(art){
        if(Des!=""){
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='art'&& lib.AttractionLibrary[key].SAR==Des){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            }
        }
        else{
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='art'){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            } 
        }
    }

    if(food){
        if(Des!=""){
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='food'&& lib.AttractionLibrary[key].SAR==Des){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            }
        }
        else{
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='food'){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            } 
        }
    }

    if(shopping){
        if(Des!=""){
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='shopping'&& lib.AttractionLibrary[key].SAR==Des){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            }
        }
        else{
            for(key in lib.AttractionLibrary){
            document.getElementById(i.toString()).innerHTML=""
            if(lib.AttractionLibrary[key].type=='shopping'){
                lib.displayAtt(key,i.toString())
            }
            i+=1 
            } 
        }
    }


}

    
    
