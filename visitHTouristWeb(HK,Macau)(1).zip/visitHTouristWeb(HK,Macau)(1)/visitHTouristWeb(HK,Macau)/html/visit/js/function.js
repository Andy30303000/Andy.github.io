
// Define global variables to store user-selected data
var selectedDestination = '';
var selectedPreferences = [];

// Simulate the acquisition of hotel data, some sample data is used here
const hotelsData = [
    { name: 'hotelA(Hongkong)', price: 100 ,image:"http://pic5.40017.cn/01/001/e0/8a/rBLkBVncgPiAHLNfAAYAwy34gw4724.jpg"},
    { name: 'hotelB(Hongkong)', price: 500,image: "https://p4-q.mafengwo.net/s12/M00/DD/07/wKgED1xBQxeADSloAAeoSapknW877.jpeg?imageMogr2%2Fthumbnail%2F%211360x760r%2Fgravity%2FCenter%2Fcrop%2F%211360x760%2Fquality%2F90"  },
    { name: 'hotelC(Macao)', price: 1000 ,image: "http://www.cntgol.com/uploads/allimg/200602/1343542Z9-7.png" }
];

// Generate a list of hotels based on the selected destination
function selectDestination(destination){
    
    var image1 = document.getElementById('image1');
    var image2 = document.getElementById('image2');
    image1.parentNode.removeChild(image1);
    image2.parentNode.removeChild(image2);
    var imageContainer = document.getElementById('image-container');
    imageContainer.parentNode.removeChild(imageContainer);
    
    selectedDestination = destination;
    const hotelsContainer = document.getElementById('hotels');
    hotelsContainer.innerHTML = '';//insert html content

  // Sort hotel data in ascending order of price
const sortedHotels = hotelsData.sort((a, b) => a.price - b.price);

  //Generate hotel card
sortedHotels.forEach((hotel) => {
    const hotelCard = document.createElement('div');
    hotelCard.className = 'hotel-card';
    hotelCard.innerText = `${hotel.name} - price:${hotel.price}HKD`;
    hotelsContainer.appendChild(hotelCard);
    const hotelImage = document.createElement('img');
    hotelImage.src = hotel.image;
    hotelImage.width = 200;
    hotelImage.height = 100;
    hotelCard.appendChild(hotelImage)
});

  // Displays preferences

    document.getElementById('preferences').style.display = 'block';
    
}


function showSelectedPreferences() {if(selectedDestination=="Hong Kong"){
  const architecture = document.getElementById('architecture').checked;// return true or false
  const nature = document.getElementById('nature').checked;
  const art = document.getElementById('art').checked;
  const food = document.getElementById('food').checked;
  const shopping = document.getElementById('shopping').checked;

  selectedPreferences = []; 
  if (architecture)selectedPreferences.push({ preference: 'Humanistic Architecture', content: 'The Monster Building is an iconic residential building complex in eastern Hong Kong Island. In the recent years, it has become a very popular spot to take photographs, especially for Instagrammers and urban explorers, the building is one of the most seen places in Hong Kong on Instagram.People are impressed by the building\'s unique symmetry and striking density. When standing on a courtyard of the building and looking up, you will see the towering concrete buildings rise on all three sides, leaving only a small, U-shaped gap of sky on the top.<br><img src=html/building.png><a href="https://thetowerinfo.com/monster-building-hong-kong/"><br>click me for more</a>' });

  if (nature)selectedPreferences.push({ preference: 'Natural Scenery', content: 'Hong Kong Park is a public park next to Cotton Tree Drive in Central, Hong Kong. It was built at a cost of HK$ 398 million and opened on 23 May 19911. The park covers an area of 80,000 square metres (860,000 sq ft) and is an example of modern design and facilities blending with natural landscape. The park integrates modern design and natural beauty providing a place for relaxation. It holds the biggest greenhouse in Southeast Asia, Forsgate Conservatory, and the Tea Ware Museum and Visual Arts Center are also inside it.<img src=html/hkpark.png><a href="https://www.lcsd.gov.hk/en/parks/hkp/"><br>click me for more</a>' });
  if (art)selectedPreferences.push({ preference: 'Art', content: 'Established in 1962, HKMoA is the first public art museum in the city, now custodian of an art collection of over 19,500 items, representing the unique cultural legacy of Hong Kong\'s connection across the globe. By curating a wide world of contrasts, from old to new, Chinese to Western, local to international, with a Hong Kong viewpoint, we aspire to refreshing ways of looking at tradition and making art relevant to everyone, creating new experiences and understanding.<br><img src=html/artmuseum.png><br><a href="https://hk.art.museum/en/web/ma/home.html">click me for more</a>' });
  if (food)selectedPreferences.push({ preference: 'Food and Drinks', content: 'Roast Goose is a traditional specialty of Cantonese cuisine:It is a whole goose roasted with secret ingredients, cut into small pieces, each piece with skin, meat and soft bone, and eaten with plum sauce.<br><img src=html/goose.png><br><a href="https://www.chinahighlights.com/hong-kong/food-restaurant.htm">click me for know more</a><br><br>Hong Kong-style milk tea is a tea drink made from Ceylon black tea and milk (usually evaporated milk and condensed milk). It is usually part of lunch in Hong Kong tea culture. Hongkongers consume approximately a total of 900 million glasses/cups per year. Although originating from Hong Kong, it can also be found overseas in restaurants serving Hong Kong cuisine and Hong Kong–style western cuisine. In the show Top Eat 100, which aired on 4 February 2012, Hong Kong-style milk tea was listed as the 4th most popular food/drink in Hong Kong. The unique tea making technique is listed on the representative list of the Intangible Cultural Heritage of Hong Kong.<br><img src=html/milktea.png><br><a href="https://en.wikipedia.org/wiki/Hong_Kong%E2%80%93style_milk_tea">click me for know more</a>'});
  if (shopping)selectedPreferences.push({ preference: 'Shopping', content:'Located on the Victoria Dockside harbourfront of Tsim Sha Tsui, K11 MUSEA is Hong Kong\'s pioneering cultural-retail landmark. Inspired by \'A Muse by the Sea\', K11 MUSEA is designed to enrich the new consumer\'s daily life through the power of creativity, culture and innovation. A destination 10 years in the making,K11 MUSEA was crafted by renowned entrepreneur Adrian Cheng together with 100 Creative Powers, a roster of more than 100 international architects, artists and designers who sought to create the ultimate space for all to embark on a \"journey of imagination\". Since opening its doors in 2019, the museum-worthy landmark has ushered in a new era of cultural retail which speaks to the growing consumer demand for immersive experiences in art, culture, nature and commerce.<br><img src=html/K11.png><br><a href="https://www.k11musea.com/zh-hk/shop/">click me for know more</a>'});
  showSelectedPreferencesPage();}
  if(selectedDestination=="Macao"){

    const architecture = document.getElementById('architecture').checked;// return true or false
  const nature = document.getElementById('nature').checked;
  const art = document.getElementById('art').checked;
  const food = document.getElementById('food').checked;
  const shopping = document.getElementById('shopping').checked;

  selectedPreferences = [];
  if (architecture){selectedPreferences.push({ preference: 'Humanistic Architecture', content: 'Offering only suites, 3000 of them and all more than 70sqm, The Venetian Macao is an incredible, immersive hotel experience. 350 world-class shopping choices line a masterfully reconstructed Grand Canal, bridges spanning each bank, just as they do in Venice. An incredible array of dining options, from the food court to the Michelin-starred Golden Peacock to room service, bring guests the best of global cuisines no matter their appetite.<br><img src=html/weinisi.png><br><a href="https://www.venetianmacao.com/"><br>click me for more</a>' });}
  if (nature){selectedPreferences.push({ preference: 'Natural Scenery', content: 'Seac Pai Van Park is Macau\'s largest natural green area and is a popular spot for family outings. Here you will find children\'s playgrounds, picnic areas, flowerbeds, a small zoo with several species of monkeys, and a large walk in aviary with peacocks, pheasants, and other colorful species.<br><img src=html/beach.png><br><a href="https://theculturetrip.com/asia/china/articles/most-beautiful-places-to-experience-nature-in-macau"><br>click me for more</a>' });}
  if (art){selectedPreferences.push({ preference: 'Art', content: 'The Macao Museum of Art (MAM), under the Cultural Affairs Bureau of the Macao SAR Government, was established on 19th March 1999. With a total area of 10,192 square metres and exhibition spaces of more than 4,000 square metres, it is the largest museum dedicated to cultural relics and arts in Macao. The museum is a five-storey building with different types of exhibition areas: the 4th floor is for Chinese traditional art; the collections of MAM are displayed on the 3rd floor; a large special gallery is on the 2nd floor; an auditorium, the Museum Shop and a temporary exhibition area are located on the 1st floor; and the Zero Square is on the ground floor. MAM also manages the adjacent Handover Gifts Museum of Macao – Handover Gifts Exhibition Gallery, the Art Square, the Kun Iam Ecumenical Centre and the Academia Jao Tsung-I near Tap Seac Square.<br><img src=html/art.png><br><a href=""><br>click me for more</a>'});}
  if (food){selectedPreferences.push({ preference: 'Food and Drinks', content: 'The Portuguese egg tart is Macau\'s most famous food. It consists of a flaky pastry shell, with a rich, sweet egg custard filling with a consistency similar to creme brulee. A caramelized top plays an integral role in the taste.<br><img src=html/food.png width="500" length="500"><br><a href="https://edition.cnn.com/travel/article/macau-must-try-foods/index.html"><br>click me for more</a><br>Pretty trendy these days, kombucha is probiotic drink fermented from tea. With some bubbles and a slight aftertaste, it\'s ideal especially when the heat hits. Summers in Macau can be tough, but there\'s nothing kombucha can\'t fix! Have it plain or mixed with an alcoholic boost and you might just find your next favourite mix. One of the best places to have kombucha is Cha Bei, in Galaxy Macau, which combines a pretty and classy atmosphere with healthy meals and lavish drinks, including their exclusive Taboocha! Blissful Carrot serves this sparkly and refreshing drink as well called Blissful BomBooch and best yet, it\'s homemade, so give it a try!<br><img src=html/drink.png width="500" length="500"><br><a href="https://macaulifestyle.com/dining/macau-drinks-guide/"><br>click me for more</a>'});}
  if (shopping){selectedPreferences.push({ preference: 'Shopping', content:'The indoor shopping area is punctuated by oversized chandeliers and contemporary art installations. Apart from a stable of high-end brands, the mall is also home to a Pierre Herme bakery.<br><img src=html/market.png width="500" length="500"><br><a href="https://www.tripadvisor.com/Attractions-g664891-Activities-c26-Macau.html"><br>click me for more</a>'});}
  showSelectedPreferencesPage();}
  
}


function showSelectedPreferencesPage() {
  const selectedPreferencesContainer = document.getElementById('selected-preferences');
  selectedPreferencesContainer.innerHTML = '';

  selectedPreferences.forEach((item) => {
    const preferenceSection = document.createElement('div');
    preferenceSection.innerHTML = `<h2>${item.preference}</h2><p>${item.content}</p>`;
    selectedPreferencesContainer.appendChild(preferenceSection);
  });

  selectedPreferencesContainer.style.display = 'block';
}